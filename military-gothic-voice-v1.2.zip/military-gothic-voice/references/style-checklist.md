# Military Gothic Voice — Final Style Checklist

Run before returning any prose. Each unchecked box is a revision pass.
Do not return prose with unchecked boxes.

---

## Sentence level

- [ ] Narration is formal; dialogue is natural. The gap between them is maintained throughout.
- [ ] Action scenes: short sentences (8–18 words) with dominant verbs. Zero qualifiers.
- [ ] Rout/overwhelm: single long sentence (40–70 words) if loss of control is the content.
- [ ] Reflection scenes: long clause-heavy sentences (20–45 words).
- [ ] The four-stage pulse (entry, expansion, complication, cut) present at the paragraph level.
      Anti-mechanical: no three consecutive paragraphs with identical pulse shape.
- [ ] No adverb-modified attribution verbs anywhere.
- [ ] Participial phrases carry atmosphere inside the grammar of action — not in separate
      descriptive sentences.
- [ ] Em dash used only for: (a) narrator commentary within attribution, or (b) subordinate
      clarification in a long introspective sentence. Never for dramatic pause, trailing effect,
      or emotional intensification. Maximum one per paragraph.
- [ ] Single-line paragraphs used for one of three structural functions only: (a) crystallisation
      terminus, (b) rhythm beat within counting or enumeration, (c) interruption of interior by
      exterior action. Never for dramatic emphasis.
- [ ] Single-line paragraphs not used more than once every three to four pages.
- [ ] Physical anchor in every introspective paragraph: at least one concrete noun (body part,
      surface, object, sound, smell). No paragraph of pure abstraction.

---

## Vocabulary

- [ ] Primary six qualifiers (merely, still, already, somehow, in truth, of course): narration
      only — never in dialogue, never in action mode. No instance within 400 words of its nearest
      repeat. Mandatory scan: locate every instance, map positions.
- [ ] Secondary qualifiers (probably, most likely, no doubt): narration only, not action mode.
      May appear slightly more frequently than primary six.
- [ ] Philosophical vocabulary (void, mortal, flesh, soul, shadow, ruin, ash, dust, persist,
      endure, remain, remnant, vestige): narration only, never in dialogue.
- [ ] Setting terminology introduced with one physical qualifier, not an explanatory parenthetical.
- [ ] No hope or faith vocabulary unless being actively undermined in the same or next sentence.
- [ ] Vocabulary cluster consistent within each passage. No cluster crossover.
- [ ] "Something like [state]" construction used where alienated approximation applies.

---

## Perspective

- [ ] Free indirect discourse active — thoughts exist in narration without hard tags ("he
      thought," "he realised," "she noticed," "she felt" as state reports).
- [ ] "wonders" permitted as a soft tag for open-ended speculation. Not flagged as a violation.
- [ ] Character observes themselves thinking at least once per significant scene.
- [ ] Self-observation sentences: 2–6 words, flat, unqualified. After significant emotional beats.
- [ ] Temporal intrusions: 1–3 sentences only, triggered by sensory or emotional prompts,
      immediate return to present. No flashback sections.
- [ ] Interiority contains at least one loop, self-contradiction, or distrusted inference.
      No clean-line interiority (question → qualified answer → acceptance).
- [ ] No zoom-out omniscience in battle scenes. No collective language without POV filter.

---

## Dialogue

- [ ] Every exchange contains subtext — real meaning is one step behind stated meaning.
- [ ] Responses shorter than the speeches that prompted them.
- [ ] Agreement used to disagree (Rule 3) at least once per major scene.
- [ ] Rule 4b present where a character of status agrees while correcting the assumed premise.
- [ ] Action beats replace attribution where possible. Attribution-free sequences used when
      context makes speaker clear.
- [ ] Action beats do not explain themselves. No annotation after the action verb.
- [ ] Attribution defaults to "said." No adverb modification.
- [ ] Most important information in the shortest response.
- [ ] No philosophical vocabulary in any line of dialogue.
- [ ] Multi-sentence speeches: attribution after first sentence, not last.

---

## World-building

- [ ] No explanatory parenthetical for setting terminology. Assume-and-proceed.
- [ ] Environment described in terms of condition and history — not emotional atmosphere.
- [ ] Battle scenes restricted to POV character's direct sensory reach.
- [ ] Specific body parts, specific weapons, specific sounds in combat. No "chaos ensued."
- [ ] Three-stage action sequence: opponent action → response → named physical consequence.

---

## Theme

- [ ] POV character has a past self and a present self in tension.
- [ ] Characters act despite inadequate reasons — duty without faith.
- [ ] Physical power or competence carries visible cost.
- [ ] At least one motivating force traces to someone no longer present.
- [ ] Theme is demonstrable from what characters do — not from what they say.
- [ ] No character has articulated their theme aloud.

---

## Forbidden — any of these present means revise

- [ ] Ellipsis for emotional effect in narration
- [ ] Em dash for dramatic pause, trailing effect, or emotional intensification
- [ ] Nature directly reflecting character's feelings
- [ ] Character articulating their theme aloud
- [ ] Hope or faith stated without qualification
- [ ] "he felt X" without a following complicating observation
- [ ] Omniscient battle narration
- [ ] Adverb attribution
- [ ] Philosophical vocabulary in dialogue
- [ ] Action beats that explain what they mean
- [ ] Flashback sections (more than one paragraph of sustained past memory)
- [ ] Three consecutive paragraphs with identical pulse shape
