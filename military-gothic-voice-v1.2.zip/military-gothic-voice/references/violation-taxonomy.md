# Military Gothic Voice — Violation Taxonomy

Full catalogue of violation types: wrong version, correct version, correction method.
Used as primary tool during `mgv-manuscript-diagnosis` Step 5.

---

## Layer 1 — Structural

### Perspective drift
**Wrong:** *The battle raged across three sectors. Simultaneously, Varn fought his way through
the corridor.*
**Right:** *Varn pushed through the corridor. Somewhere behind him, close enough to feel
through the floor, something large was dying.*
**Correction:** Remove anything outside the POV character's direct sensory range. If it cannot
be heard, seen, smelled, or felt: cut. What the character cannot perceive directly must be
inferred by them — or not known.

### Wrong paragraph pulse
**Wrong:** Three paragraphs of expansion with no entry or cut. Reader floats.
**Right:** Entry (bare declarative) → Expansion (2–4 sentences) → Complication (cuts against
expansion) → Cut (3–5 words, flat, no qualifier).
**Correction:** Find the natural entry and cut points in the material. Do not add all four
artificially — restructure around what already exists.

### Flashback section
**Wrong:** A paragraph or more developing a memory into its own scene.
**Right:** One to three sentences of temporal intrusion, triggered by a specific prompt, then
immediate return to present action.
**Correction:** Cut everything in the memory beyond the first triggering image and one sentence
of consequence. The memory must leave its mark on the present, not compete with it.

### Omniscient battle narration
**Wrong:** *The right flank collapsed under heavy fire. Three companies broke. The commander
saw the end.*
**Right:** *He heard the right flank go — not the order, but the sound of it, the particular
quality of volume that meant discipline had failed. He did not look.*
**Correction:** Filter every observation through the POV character's physical senses. Anything
they cannot perceive must either be inferred (with the inference attributed to the character)
or cut.

### Dialogue symmetry
**Wrong:** Both characters explain their position fully. The reader understands both positions
completely.
**Right:** One speaker deflects, qualifies, or answers the wrong question. The reader
understands one position and infers the other through what is not said.
**Correction:** Identify the character whose position is clearer. Cut or deflect their most
explicit statement. Move their real meaning into an action beat or a one-word response.

---

## Layer 2 — Voice

### Tagged thought
**Wrong:** *He thought about what she had said. He wondered if she was right.*
**Right:** *What she had said sat in him wrong. Was she right? Probably. That was the problem.*
**Correction:** Remove the tag. Let the thought exist as narration. Allow tense to slip to
present within the thought. Note: "wonders" in present tense is NOT tagged thought — leave it.

### Pathetic fallacy
**Wrong:** *The rain fell like grief. The sky was weeping with him.*
**Right:** *The rain had not stopped in three days. The ground was past absorbing it.*
**Correction:** Describe the environment's condition and history. The atmosphere arrives from
the described condition — never from direct emotional mapping.

### Character articulating theme
**Wrong:** *"We keep fighting because that's all we have left. That's what we are now."*
**Right:** *He loaded the weapon. There was nothing else to do.*
**Correction:** Remove the thematic statement. Replace it with the action that demonstrates
the theme without naming it.

### Narrative/dialogue voice collapse
**Wrong:** *"The void consumes us all in the end. We are merely remnants persisting in the dark."*
**Right:** *"We're losing."*
**Correction:** Strip philosophical vocabulary from dialogue. Replace with the plainest possible
statement of the character's actual position.

### Smooth interiority
**Wrong:** *Was he afraid? Perhaps. He had learned not to fight the recognition. It was useful.*
**Right:** [Introduce a loop, self-contradiction, or distrusted inference before resolution]
**Correction:** Identify where the thinking resolves cleanly. Insert: the character reaches
a conclusion → notices something wrong with it → or observes they've reached it too easily
and distrusts the speed of the arrival.

---

## Layer 3 — Sentence mechanics

### Mode mismatch (action scene)
**Wrong:** *He considered, at length, the implications of the enemy's advance, noting the
methodical quality of their approach...*
**Right:** *They were methodical. That was the problem. He moved left.*
**Correction:** Identify the mode. Cut to the correct sentence length. In action mode: no
sentence over 18 words (unless rout variant — verify context first).

### Missing cut
**Wrong:** Paragraph builds through entry, expansion, complication — then another expansion.
**Right:** After complication: one sentence of 3–5 words, flat, no qualifier.
**Correction:** Find the last substantive claim in the paragraph. Write a four-word sentence
naming it plainly or drawing the conclusion. Cut everything that follows.

### Separated action-atmosphere
**Wrong:** *She ran. The street was dark and wet. Voices shouted behind her.*
**Right:** *She ran, her boots cracking through the wet surface of the street, the voices
behind her closing.*
**Correction:** Move atmosphere into the grammar of action via participial phrases.

### Annotated action beat
**Wrong:** *He closed the file, the way a man does when he's already made the decision.*
**Right:** *He closed the file.*
**Correction:** Remove everything after the action verb. If the meaning collapses: the action
is wrong — find a different action. If the meaning holds: the annotation was deadweight.

### Em dash misuse
**Wrong (pause):** *She turned — and stopped.*
**Wrong (trailing):** *He had nothing left —*
**Wrong (intensification):** *He was afraid — genuinely afraid.*
**Right (attribution commentary):** *'I'll stay,' she said — not a decision, so much as an
acknowledgement of what had already been decided.*
**Right (introspective aside):** *He had learned — in the years after — that waiting was a skill.*
**Correction:** If the em dash is doing anything other than (a) narrator commentary within
attribution or (b) subordinate clarification in an introspective sentence: replace with a full
stop, restructure, or cut the phrase.

---

## Layer 4 — Vocabulary

### Qualifier clustering
**Wrong:** *Still, he waited. He was still uncertain. He still held the weapon.*
**Right:** *He waited. Uncertainty had become a kind of background condition. The weapon
stayed in his hand.*
**Correction:** Locate every instance of the nine qualifiers. If any appears twice within
400 words (primary six) or frequently in action mode (all nine): cut the second instance.
Do not rephrase to keep both.

### Philosophical vocabulary in dialogue
**Wrong:** *"We persist. We endure. That is all that remains of us."*
**Right:** *"We're still here."*
**Correction:** Replace every word from the philosophical vocabulary list (void, mortal, flesh,
soul, shadow, ruin, ash, dust, persist, endure, remain, remnant, vestige) with the plainest
possible equivalent when it appears in dialogue.

### Wrong cluster words
**Wrong (duty-without-faith scene):** *He hoped, still. The faith in him had not entirely died.*
**Right:** *He had not stopped. That was the thing. Not stopping was the only coherent response.*
**Correction:** Identify the active cluster. Remove words from other clusters. Replace with
cluster-appropriate vocabulary or with plain action.

### Adverb attribution
**Wrong:** *"Come with me," she said urgently.*
**Right:** *"Come with me." She was already moving.*
**Correction:** Remove the adverb. Move the tonal information into an action beat before or
after the line.
