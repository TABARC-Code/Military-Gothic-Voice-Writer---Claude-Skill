# Military Gothic Voice — Setting Registers
## Confirmed vocabulary registers by setting

Load the appropriate register before generation. Do not ask the user for terminology when
working in these settings.

---

## Register 1: Death Guard / Chaos

**Vocabulary cluster:** decay-and-persistence
**Dominant words:** rot, crust, patina, fused, coated, encrusted, absorbed, consumed, thickened,
patient, gradual, eventual, wasting, fattening, diminishing, congested

**Confirmed behaviour:**
Decay processes are neutral, even patient — never described as evil. The rot is theological
commitment made flesh. Characters are aware of their condition and have accepted it. Architecture
extrudes, grows, and accretes — never built in the conventional sense. The ship IS the moral
condition of the Legion made spatial. Pain is registered and ignored, or welcomed.

**Characteristic humour:** Dark, wry, ironic acceptance. "That counts as forgiveness, probably."

**Familiars and small warp creatures:** Affectionate creature vocabulary — "cooed," "nuzzled,"
"chittered," "snickering," "gurgling." The tenderness against the grotesquerie is real, not
ironic. This is the Nurgle affect.

**Qualifier characteristic:** "of course" appears frequently (acceptance of the inevitable).
"Gradually" is the temporal qualifier of decay processes — the slow administrative pace.

**Confirmed character registers:**
- Measured, question-based, philosophical: *"What happened?" / "Run the numbers."*
- Terse, contemptuous: *"Not good enough." / "Get it done."*
- Epigrammatic, knowing: *"This year, then, I hope you will listen."*
- Clinical, precise: *"Rather proud of the crews, lord." / "I'd normally be taking your progenoids."*

---

## Register 2: Space Marine (Loyal) — Iron Hands variant / Astra Militarum

**Vocabulary cluster:** duty-without-faith
**Dominant words:** obligation, purpose, task, service, function, endure, serve, call, sworn, honoured

**Iron Hands register:** Characters defined by institutional role. Augmentation is functional
and morally compromised. The coldness of Iron Hands is always measured against the warmth of
Astra Militarum sections — the contrast is the moral text. Bodies accumulate damage permanently.
Nothing heals completely.

**Astra Militarum sub-register:** Warmth is possible here, absent from Space Marine sections.
Mortal soldiers: immediate, sensory, frightened — the smell and sting of the environment always
present. Pain disables. Characters believe in things, even if the things are insufficient.

**Confirmed character registers:**
- Short, solution-oriented, contemptuous of waste: *"We'll kill 'em all."*
- Measured, concerned with men, soft voice: *"The death of heretics brings me joy; the death of
  the ignorant does not."*
- Cold, functional, no affect: *"They are mistaken. Such error is fatal."*

---

## Register 3: Inquisition / Political

**Vocabulary cluster:** political-threat
**Dominant words:** careful, scheme, position, advantage, rival, enemies, power, leverage, assets

**Confirmed behaviour:** Information is currency. Sentences shorten in political exchanges.
Adjectives thin out almost entirely. Information density increases. Caution is embedded in
sentence structure: conditional clauses, hedges, "I believe," "it would appear." Characters
manage information asymmetry constantly — they know things others don't and conceal what they
know while appearing to share.

**Confirmed character registers:**
- Arch, theatrically candid: *"I'll not sweeten this for you."* Gives information because she
  controls which information is given.
- Calculating, self-amused: *"It's a game, is it not? Play it hard."* Always a step ahead of
  appearing to be a step ahead.
- Formal, rigorous, ill-at-ease: *"Anything that might carry a trace."*
- Military, pragmatic: *"Stitch faster. I've got squads who haven't been rotated."*

---

## Register 4: Warhammer Fantasy — Empire (Military / Political)

**Vocabulary cluster:** duty-without-faith (military), political-threat (court)

**Confirmed behaviour:** Gothic fantasy register — churches, merchants, river trade, minted
coins, mountains. Physical landscape is real: distance matters, weather has consequences, armies
exhaust themselves. Political scenes nearly identical to Inquisition register. Supernatural
intrudes without explanation — "What are you?" receives no answer. The social hierarchy is
rigid and its cracks are the story.

**Confirmed character registers:**
- Arrogant, playing power: *"That's nice."* (to the Emperor's messenger)
- Pragmatic, contemptuous of incompetence: *"I've seen enough of this. We'll head to the Keep."*
- Cautious, bureaucratic, notes everything: *"He hoped so. Just for once, it would be nice
  for the surprises to be good ones."*

---

## Cross-setting constants (confirmed across all books)

These appear regardless of setting:

**Identity-under-erasure cluster** (*once, before, then, no longer, had been, what remained*)
— all settings when transformation or loss of self is present. Key word: *once.*

**Self-observation sentences** — 2–6 words, flat, after significant emotional beats.

**"Of course" as weariness/acceptance** — all registers.

**Environment as structural mirror** — never pathetic fallacy; always functional/historical.

**Numbers as psychological anchors** — counting and specific numbers when characters are
reaching for certainty in uncertain conditions.

**Agreement-used-to-disagree** (Rule 3) — all political and dialogue-heavy sections.

**Cost of strength in the body** — augmentation, wound, condition always carries moral weight.

**"Something like [state]" construction** — alienated approximation, strongest in Death Guard
and Iron Hands registers.
