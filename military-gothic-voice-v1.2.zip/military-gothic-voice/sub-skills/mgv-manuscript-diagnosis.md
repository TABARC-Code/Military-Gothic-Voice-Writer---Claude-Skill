---
name: mgv-manuscript-diagnosis
version: 1.0.0
title: Military Gothic Voice — Manuscript Diagnosis
role: sub-skill
user-invocable: false
model: sonnet
effort: high
calls: mgv-perspective-interiority, mgv-dialogue-subtext, mgv-vocabulary-fingerprints, mgv-sentence-architecture
called-by: SKILL.md
---

# Military Gothic Voice — Manuscript Diagnosis

Reads existing prose, identifies violations by type and severity, sequences corrections, and
flags what to leave alone. Mandatory first step for all revision. Do not attempt revision by
inference — inference catches surface features and misses structural violations that require
sequenced correction.

---

## Sequential thinking procedure

1. **Read the entire passage once without marking anything**
2. **Identify baseline:** mode, distance, word count, paragraph count, first impression
3. **Run Layer 1 scan** (structural) — complete before Layer 2
4. **Run Layer 2 scan** (voice) — complete before Layer 3
5. **Run Layer 3 scan** (sentence mechanics) — complete before Layer 4
6. **Run Layer 4 scan** (vocabulary) — last
7. **Severity classification** — classify each violation
8. **Preserve identification** — flag what is working and must not be touched
9. **Apply corrections in layer order using `references/violation-taxonomy.md` as primary tool**
   — do not improvise corrections
10. **Return full output** in the specified format

---

## Step 1: Read without correcting

Read the entire passage. Identify:
- Overall mode: action / introspection / dialogue / mixed (which dominates)
- Narrative distance: close third / mid third / distant / first person
- Approximate word count and paragraph count

Do not mark violations during this pass. Orientation only.

---

## Step 2: Violation scan by layer

---

### Layer 1 — Structural violations (fix first)

Applying surface corrections to a passage with unresolved structural violations is wasted
effort — surface corrections are undone when structure changes.

**Perspective drift**
Narration shifting distance mid-scene without narrative purpose; narrator accessing information
outside POV character's direct sensory range.
*Detection:* Any sentence describing something outside the character's physical position.
Any sentence reporting on the character from outside their own perception.

**Wrong paragraph pulse**
Missing the entry / expansion / complication / cut structure, or the same pulse shape repeated
mechanically across three or more consecutive paragraphs.
*Detection:* Identify which stage is absent. Check three consecutive paragraphs for identical
resolution pattern.

**Flashback sections**
Extended past intrusion developing its own scene, setting, and momentum.
*Detection:* Any past-tense memory passage longer than one paragraph. Any memory that
introduces new characters, settings, or events without immediately returning to the present.

**Omniscient battle narration**
Battle description beyond what the POV character can directly perceive.
*Detection:* Any sentence describing events the character cannot see. Any collective description
("the right flank," "the enemy forces") without the character as perceiving subject.

**Rout sentence exception:** A very long action sentence (40–70 words) in a rout or overwhelm
context is NOT a violation — it is a confirmed technique. Verify context before flagging.

**Dialogue symmetry**
Both speakers explaining their positions fully. No subtext gap.
*Detection:* Find exchanges where each speaker's position is completely legible by the end.
Responses longer than or equal to the speeches that prompted them.

---

### Layer 2 — Voice violations (fix second)

**Tagged thought**
Hard tags: "he thought," "he realised," "she noticed," "she felt" as a state report.
*Not a violation:* "wonders" in present tense — permitted soft tag for open-ended speculation.
*Detection:* Search for "he/she/they + thought / realised / noticed / felt" in past tense as
state reports. Do not flag "wonders" used for genuine uncertainty.

**Pathetic fallacy**
Environment described as directly reflecting character's emotional state.
*Detection:* Any sentence where weather, landscape, or setting is described in terms of
emotional quality or sympathy with the character.

**Character articulating theme**
A character makes a speech that states the thematic meaning of the scene directly.
*Detection:* Any line of dialogue or internal monologue naming what the scene is "about" or
what the character "fights for."

**Self-observation absent**
No self-observation sentence after a significant emotional beat.
*Detection:* Locate significant emotional moments. Check for a 2–6 word self-observation
sentence following each.

**Smooth interiority**
Character's thinking moves in a clean line from question to qualified answer.
*Detection:* Read every interiority passage. If it resolves cleanly — question → qualified
answer, even if questioned once — it is too smooth.

**Narrative/dialogue voice collapse**
Character speaking with philosophical vocabulary (void, mortal, flesh, soul, shadow, ruin,
ash, persist, endure, remain) that belongs to the narrator.

---

### Layer 3 — Sentence mechanics violations (fix third)

**Mode mismatch**
Wrong sentence length for the current mode. Action mode over 18 words (unless rout variant).
Introspective mode under 20 words.

**Missing cut**
Paragraphs that end on expansion or complication rather than a flat short concluding sentence.
*Detection:* Last sentence of each paragraph — is it 3–5 words? Does it cut or continue?

**Separated action-atmosphere**
Action and atmosphere in distinct sentences rather than integrated via participial stacks.
*Detection:* Consecutive sentences where one describes action and the next describes setting
with no grammatical connection.

**Annotated action beats**
Action beats that explain what the action means.
*Detection:* Any action beat followed by "the way," "as if," "like someone who," or any
explanatory construction.

**Em dash misuse**
Em dash for dramatic pause, trailing effect, or emotional intensification.
*Detection:* Every em dash — is it appending narrator commentary to attribution, or providing
subordinate clarification within an introspective sentence? If neither: misuse.

---

### Layer 4 — Vocabulary violations (fix last)

**Qualifier clustering**
Same qualifier twice within 400 words.
*Detection:* Locate every instance of all nine qualifiers. Map word-distance from nearest repeat.

**Philosophical vocabulary in dialogue**
Any word from the philosophical vocabulary list in a line of dialogue.

**Wrong cluster words**
Vocabulary from one thematic cluster in a passage governed by a different cluster.

**Hope/faith vocabulary without ironic framing**
"Hope" or "faith" in a duty-without-faith passage without immediate ironic qualification.

**Adverb attribution**
Any attribution verb modified by an adverb.

---

## Step 3: Severity classification

**Structural break:** The passage cannot function in this voice with this violation present.
Must fix before any other revision.

**Voice leak:** The passage reads as generic fiction rather than this voice. Degrades quality
but does not break the passage.

**Mechanical drift:** Rhythm is off. Affects reading experience but the passage communicates.

**Surface residue:** Word-level issue that polish can address without restructuring.

---

## Step 4: Preserve identification

Before any edit, identify what is working. Flag explicitly. Revision works around these.

Mark for preservation:
- Passages already in correct free indirect discourse
- Action beats that do not annotate themselves
- Dialogue exchanges with genuine subtext gap
- Sentences carrying atmosphere inside the grammar of action
- Self-observation sentences doing real work
- Any moment where the character observes themselves thinking with genuine irony

---

## Step 5: Apply corrections in layer order

Work through: Layer 1 → Layer 2 → Layer 3 → Layer 4.

**Use `references/violation-taxonomy.md` as primary tool for each violation found.** Do not
improvise corrections. The taxonomy documents the correct version, the wrong version, and
the correction method. Improvised corrections regularly introduce new violations in adjacent
layers. After each layer: quick scan of the affected passage for new violations introduced.

---

## Output format — in strict order

**1. Diagnostic summary**
Mode, distance, word count, paragraph count, total violations by layer (counts only)

**2. Violation list**
Each violation: layer, severity, quoted location (under ten words), correction required
in one sentence

**3. Preserve list**
What is working and must not be touched

**4. Revised prose**
Full corrected passage

**5. Post-revision note**
One remaining risk (most likely to recur) and one observation about what the revision changed
that the user should know

---

## Skill relationships

**Called by:** `SKILL.md` (master) — mandatory for all revision and diagnosis; master passes
input prose and task mode

**Calls:**
- `mgv-perspective-interiority` — Layer 1 perspective violations and Layer 2 tagged thought /
  smooth interiority
- `mgv-dialogue-subtext` — Layer 2 narrator/dialogue voice collapse
- `mgv-vocabulary-fingerprints` — Layer 4 surface vocabulary corrections
- `mgv-sentence-architecture` — Layer 3 mode mismatch, missing cut, separated action-atmosphere

**Bidirectional data flows:**

**Master → this skill:**
- *Receives from master:* input prose, task mode (revision — apply all corrections; diagnosis —
  return violation list and preserve list only, no corrections), scene context if known (setting,
  POV character, approximate mode)
- *Returns to master:* full output in the specified format (diagnostic summary, violation list
  with layer/severity/location/correction, preserve list, revised prose, post-revision note);
  the post-revision note includes the dominant risk for recurrence in subsequent drafts
- *Master uses this return to:* for revision mode — select which correction sub-skills to invoke
  based on which layers have violations; for diagnosis mode — present findings to user

**This skill → `mgv-perspective-interiority` (Layer 1 and 2):**
- *Sends:* Layer 1 violations — perspective drift (quoted location, what omniscient information
  was present) and omniscient battle narration (quoted location, information that exceeded sensory
  range, character's confirmed position); Layer 2 violations — tagged thought (quoted location,
  specific tag type), smooth interiority (quoted location, description of clean-line arc),
  self-observation absent (quoted location of emotional beat lacking observation sentence)
- *Receives:* corrected prose with Layer 1 and 2 violations resolved; list of corrections applied;
  any new violations introduced (typically Layer 3 — removing a tagged thought can create a mode
  mismatch in the untagged version)
- *Uses return to:* verify Layers 1 and 2 are resolved; note any new Layer 3 violations before
  that scan

**This skill → `mgv-dialogue-subtext` (Layer 2 voice collapse):**
- *Sends:* Layer 2 narrator/dialogue voice collapse violations — the specific dialogue lines
  containing philosophical vocabulary (void, mortal, flesh, soul, shadow, ruin, ash, persist,
  endure, remain), location, and the specific words requiring replacement
- *Receives:* corrected dialogue exchange with philosophical vocabulary replaced by character-
  register equivalents; character register confirmed; list of any additional dialogue violations
  noticed during correction (flagged only — not independently corrected)
- *Uses return to:* replace the Layer 2 violation; log flagged dialogue violations for potential
  separate revision instruction

**This skill → `mgv-vocabulary-fingerprints` (Layer 4):**
- *Sends:* Layer 4 violation list — qualifier clustering (which of the nine qualifiers, positions,
  word-distance from nearest repeat), philosophical vocabulary in dialogue (specific lines),
  wrong cluster words (identified words, which cluster they belong to, which cluster is active),
  hope/faith without irony (location), adverb attributions (attribution verb and adverb, location)
- *Receives:* corrected prose passage with all Layer 4 violations resolved; confirmation no new
  violations introduced
- *Uses return to:* finalise revised prose; include in output to master

**This skill → `mgv-sentence-architecture` (Layer 3):**
- *Sends:* Layer 3 violation list — mode mismatch (quoted sentence, current word count, active
  mode, correct length range for that mode), missing cut (paragraph end quoted, current ending),
  separated action-atmosphere (both sentences quoted), annotated action beat (beat with
  annotation quoted), em dash misuse (location, misuse type from: dramatic pause / trailing
  effect / emotional intensification)
- *Receives:* corrected prose with Layer 3 violations resolved; list of corrections applied and
  decisions made (e.g., rout sentence preserved if context warranted, with justification); any
  new violations introduced
- *Uses return to:* verify Layer 3 resolved; note any new violations before Layer 4 scan

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
