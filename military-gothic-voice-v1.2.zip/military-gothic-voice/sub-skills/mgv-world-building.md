---
name: mgv-world-building
version: 1.0.0
title: Military Gothic Voice — World-Building Technique
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: —
called-by: SKILL.md, mgv-manuscript-diagnosis
---

# Military Gothic Voice — World-Building Technique

Controls how setting terminology is introduced, how environments function as structural
mirrors (never emotional ones), and how physical conflict is rendered from inside one
character's sensory range. Techniques transfer to any genre. Terminology changes with setting.

---

## Sequential thinking procedure

1. Confirm setting brief is loaded; if not, return to master — generation is blocked
2. For any setting-specific term: apply assume-and-proceed method (one physical qualifier; no
   explanation; move on)
3. For environmental description: describe condition and history, not atmosphere or emotion
4. For conflict: identify POV character's sensory range and restrict all narration to within it
5. For each physical engagement: opponent's action → character's response → named consequence
6. Return: setting terms introduced with qualifiers, environment as structural mirror confirmed,
   conflict within intimacy rule, prose

---

## The assume-and-proceed method

Treat the fictional world the way a non-fiction writer treats a specialist subject — confident
the audience either knows or will infer. Never explain setting terminology.

**Wrong:**
> *The narthecium — a tool of augmented surgery — gleamed in his hand.*

**Right:**
> *The old narthecium with its scissor-saw mandibles intact.*

**The rule:** When introducing a setting-specific term, give it one qualified noun phrase —
a modifier or appositional phrase that implies function without defining it. Move on immediately.

**The test:** Does the qualifier tell the reader what the object *does* (explanation) or what
it *is* in the physical world (description)? Explanation: cut it. Physical description: keep it.

**Correct qualifier examples from source texts:**
- *the old narthecium with its scissor-saw mandibles* — implies surgery through physical form
- *the bolter, warm in his hands and heavier than it looked* — sensory description only
- *his armour, the needle-arrays twisted and leaking* — describes damage and physical form

**What to collect in the setting brief:**
For unknown settings: character name, faction/group, setting name, key terms with physical
descriptions (not functional ones), location name, opponent name/faction. Five questions max.
Pass the brief to `mgv-vocabulary-fingerprints` for cluster extension.

---

## Environment as structural mirror — not emotional mirror

Never write pathetic fallacy — environments that weep with the character or radiate sympathetic
atmosphere. Environments are structural mirrors: they reflect not what the character feels but
what the situation *is.*

**Wrong:**
> The sky was dark, mirroring his despair. The wind grieved.

**Right:**
> The rain had not stopped in three days. The ground was past absorbing it.

**The method:** Describe the environment in terms of its functional and historical condition.
What has it been through? What has been done to it? What is it currently in the process of
becoming? The atmosphere arrives from the described condition — the reader draws the connection
that the narrator refuses to make.

**Source text examples:**
> *Averheim looked perfectly serene in the golden light of the afternoon.* — A city scoured of
> visible damage. The serene surface is the sinister fact. The narrator does not point at it.

> *Solace excretes continually, a sludge of faecal brown that stains every orbit it has ever
> been in.* — The ship is the moral condition of the Legion made spatial. Not a metaphor — it
> simply is the Legion, spatially.

**Environmental description principles:**
- Describe materials: what things are made of, what condition they are in
- Describe processes: what is rotting, growing, accumulating, wearing away
- Describe history: not as backstory, but in the physical traces it left
- Never describe the mood: that belongs to the character in FID via `mgv-perspective-interiority`

**Ship / place as character:**
For any location central to the characters' lives over an extended period, the environment
can be given a character arc of its own — narrated directly as biography, not description.
The ship has whims. The building has accumulated something from what happened in it.
One location per work. Deploy the historical/record mode from `mgv-sentence-architecture`
for this.

---

## Battle and conflict — the intimacy rule

Every engagement is experienced from within one character's sensory range. What the POV
character cannot see, hear, smell, or feel, the narrator cannot describe. This is absolute.

**Never:**
- Zoom out to describe the wider battle
- Write "chaos ensued" or "the battle intensified" or "the right flank collapsed"
- Access information the POV character has no way to perceive
- Give a name to a combatant the character has not identified
- Use collective language: "the troops," "the enemy forces"

**Always:**
- Restrict narration to what the character can directly sense
- Describe specific body parts, specific weapons, specific sounds, named physical consequences
- Acknowledge the limit directly when it applies

**Source text example of correct limitation:**
> *He never even saw the insignias on those doors — he never knew who was killing them all.*

Not a limitation — a technique. Large-scale events feel personal and bewildering the way
actual combat does.

---

## The three-stage action sequence

For every physical engagement (strike, block, throw, shot, detonation):

**Stage 1 — Opponent's specific action:**
The specific physical action the opponent takes. Not "attacked" — the exact action: raised the
halberd, pivoted left, brought the elbow down.

**Stage 2 — Response action:**
The POV character's response. Specific. Physical. No interior reflection during active engagement.

**Stage 3 — Physical consequence:**
What happened as a result. Specific body part. Named effect. Named result.

**Source text example:**
> *He waited until the last possible moment before swerving sharply to his right, dropping low
> and ducking under the swing of the rider's halberd. The horse thundered past him. Skarr spun
> sharply, stabbing his sword-edge deep into the beast's hamstrings, severing them cleanly.*

Opponent action: *swing of the rider's halberd.* Response: *swerving, dropping low, ducking.*
Consequence: *stabbing into the hamstrings, severing them cleanly.* Named. Specific. Move on.

---

## Output specification

Return to calling skill:
- Setting brief status: [confirmed loaded / collected from user / blocked pending]
- Setting terms introduced: [list of terms used and the qualifiers applied]
- Environment method: [structural mirror confirmed / pathetic fallacy removed]
- Conflict narration: [intimacy rule maintained / omniscient moments flagged and corrected]
- Drafted or revised prose

---

## Skill relationships

**Called by:**
- `SKILL.md` (master) — for environment building and conflict sequences
- `mgv-manuscript-diagnosis` — Layer 1 omniscient battle narration corrections

**Calls:** none — terminal sub-skill

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* setting brief (confirmed loaded — key terms, faction names, location
  name, world-specific vocabulary with physical descriptions, corruption/transformation name if
  applicable), scene type (environment-only / conflict / both), whether conflict is present
- *Returns to master:* list of setting terms introduced with their qualifiers applied (confirms
  assume-and-proceed method used, no explanatory parenthetical); environment approach confirmed
  (structural mirror method — condition and history described, not atmosphere); conflict narration
  within intimacy rule (POV sensory range maintained, omniscient moments absent); drafted or
  revised prose
- *Master uses this return to:* confirm world elements are grounded before passing to vocabulary
  calibration; if setting brief was absent and this skill generated a blocking signal, master
  initiates setting brief collection before allowing generation to continue
- *Note: master (not this skill) passes the setting brief key terms to `mgv-vocabulary-fingerprints`
  for cluster extension — this skill does not call `mgv-vocabulary-fingerprints` directly*

**`mgv-manuscript-diagnosis` → this skill (revision):**
- *Receives from `mgv-manuscript-diagnosis`:* Layer 1 omniscient battle narration violations —
  specifically: the sentences that describe events outside the POV character's sensory range
  (quoted under ten words), what information exceeded the range, the character's confirmed
  physical position at that moment in the scene
- *Processes:* removes omniscient information; replaces with what the character could actually
  perceive from their position — what they hear through a wall, what they infer from sound and
  feel, what they do not know and the narrative acknowledges they do not know
- *Returns to `mgv-manuscript-diagnosis`:* corrected prose with omniscient narration replaced
  by sensory-range-appropriate perception; notes any decisions made about what information was
  cut versus what was converted to inference
- *`mgv-manuscript-diagnosis` uses this return to:* verify Layer 1 omniscience violations are
  resolved; check that information previously conveyed omnisciently has not been silently dropped
  but has been converted to acknowledged limitation

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
