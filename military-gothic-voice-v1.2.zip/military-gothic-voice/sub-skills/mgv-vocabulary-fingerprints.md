---
name: mgv-vocabulary-fingerprints
version: 1.0.0
title: Military Gothic Voice — Vocabulary Fingerprints and Register
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: —
called-by: SKILL.md, mgv-manuscript-diagnosis, mgv-thematic-engine
---

# Military Gothic Voice — Vocabulary Fingerprints and Register

Controls word choice at the level of vocabulary clusters, qualifier tics, and the gap
between narrator and character language. Applied last in the generation stack — surface
calibration after structure and voice are sound.

---

## Sequential thinking procedure

1. Identify the active vocabulary cluster for this passage
2. Confirm no cluster crossover — words from a different cluster present
3. Run mandatory qualifier scan: all nine qualifiers (primary six + secondary three);
   check position, spacing, and mode eligibility for each
4. Verify philosophical vocabulary is absent from all dialogue
5. Audit narrator/dialogue voice gap: if dialogue present, confirm character speech uses
   character vocabulary, not narrator vocabulary
6. Return: active cluster, qualifier scan results, violations flagged, corrected prose

---

## The core philosophical vocabulary — narration only

These words appear across all registers regardless of setting. They are the conceptual
skeleton of the narrative voice.

**Existential:** void, mortal, flesh, soul, shadow, ruin, ash, dust, remnant, vestige
**Process:** persist, endure, survive, remain, continue, sustain, maintain
**Interiority:** dull, throbbing, raw, acute, agonising, numb
**Temporal:** still, already, now, long ago, once, what remained
**Judgment:** merely, perhaps, surely, possibly, no doubt, in truth

**Absolute rule:** These words appear in narration only — never in dialogue. Using any of them
in dialogue is a structural break. Remove immediately and replace with the plainest character-
register equivalent.

---

## The qualifier tics — primary six

These six qualifiers carry specific semantic weight. Each must appear no more than once every
400–500 words. Overuse depletes them to zero effect. Two close occurrences of "still" do not
produce double the impact — they produce no impact for either instance.

**Mandatory scan:** Before returning any prose, locate every instance of all six. Map positions.
If any appears twice within 400 words: cut the second. Do not rephrase to keep both.

**Mode restriction:** Qualifiers appear in introspective and reflective narration only.
In action mode: zero qualifiers permitted. Remove any found. They soften what must be hard.

### "merely"
Ironic minimisation. What follows is described as smaller than it is. Draws attention to the
inadequacy of the description.
*He is merely a puppet now.* — "puppet" understates the case.
**Misuse:** Simple qualification. *He was merely tired.* — no ironic load; cut it.

### "still"
Temporal persistence against expectation. Things continuing that should have stopped, or not
changing when they should. Always slightly ominous.
*She smiled, still.* — the persistence of the smile when it should have faded is the point.
**Misuse:** Simple continuative. *He was still standing.* — no ominous register; restructure.

### "already"
The past arriving too soon. Loss pre-announced. Anticipation of something the character cannot
prevent and has not processed.
*He felt it already, the cold.* — the cold has not arrived; the character feels its approach.
**Misuse:** Simple anteriority. *She had already left.* — just sequencing; remove.

### "somehow"
Acknowledgement of improbability without explanation. Characters survive things they should
not. The word registers the miracle without resolving it.
*Somehow they had made it out.* — the how is not available. The fact is.
**Misuse:** Vague causation. *He somehow found himself agreeing.* — evasion; restructure.

### "in truth"
The narrator inserting a correction after a character's stated belief or claim. Reveals the
gap between what they said and what is actually the case.
*He had told himself it was duty. In truth, it had been fear.*
**Misuse:** Emphasis without correction. *In truth, it was a good plan.* — just agreement; cut.

### "of course"
Weariness, irony, or acceptance. Appears when a character is accepting something they had
been resisting, or acknowledging what they should have seen sooner.
*Of course he's slower.* — the moment of accepting what had been avoided.
**Misuse:** Enthusiasm. *Of course it worked!* — wrong register entirely; remove.

---

## Secondary qualifiers — lower weight, same mode restriction

**"probably"** — casual hedge and wry detachment marker. More frequent than the primary six,
but still narration only, not action mode. The trailing "probably" at sentence end signals
ironic approximation.
> *"which is probably for the best"* / *"That counts as forgiveness, probably."*

**"most likely"** — archival equivalent of "probably." Used in historical mode or by characters
who maintain formal distance from their own speculations.
> *"Some wasting Gift in his vocal cords, most likely."*

**"no doubt"** — inevitable consequence noted without enthusiasm. Weary acknowledgement of
something the character would rather not think about.
> *"No doubt he'd been scanned."*

---

## The "something like" construction — alienated approximation

Characters approximating an emotion or state they cannot fully classify.

> *"Something like a uniform still clings to his hefty frame."*
> *"He felt something like satisfaction."*
> *"Something like pity crossed her face."*

Signals alienation from interiority — the character is aware of an emotional state but cannot
place it. Characteristic of: Death Guard characters who have moved past normal emotional
responses; Iron Hands characters whose augmentation has distanced them from feeling; any
character who has spent too long in conditions where emotional classification became irrelevant.

Not a weakness. The approximation IS the characterisation.

---

## Vocabulary cluster consistency

Identify the active cluster and maintain it throughout a passage. Cluster crossover generates
tonal inconsistency.

### Duty-without-faith cluster
*obligation, purpose, task, service, function, endure, serve, call, sworn, honoured*
**Use:** Characters doing what they should even though they no longer believe in why.
**Forbidden:** hope, faith — unless immediately undercut in the same or following sentence.

### Decay-and-persistence cluster
*rot, crust, patina, fused, coated, encrusted, absorbed, consumed, thickened, patient,
gradual, eventual*
**Use:** Long-running corruption, transformation, or physical decay.
**Key characteristic:** These processes are neutral, even patient. Never described as evil.
Characters in this cluster have accepted their condition.
**Architecture note:** Environments in this cluster extrude and grow — they are not built.
The setting is the moral condition of its inhabitants made spatial.

### Identity-under-erasure cluster
*once, before, then, no longer, had been, the man he was, what remained, the thing he had become*
**Use:** Any scene involving transformation, loss of self, sustained damage, or measuring
against a previous version.
**Key word:** *once.* Characters in this cluster are always defined against what they were.

### Political-threat cluster
*careful, scheme, position, advantage, rival, enemies, power, game, rise, control*
**Use:** Political negotiations, court scenes, tactical positioning between factions.
**Effect on prose:** Sentences shorten. Adjectives thin out almost entirely. Information
density increases. The prose becomes harder and flatter.

---

## The narrator/dialogue voice gap — non-negotiable

Characters speak differently from the narrator. The gap must be maintained throughout.

**Narrator vocabulary:** formal, philosophical, clause-heavy, uses the core vocabulary above.
**Character vocabulary:** shorter, more direct, declarative, often incomplete. Deflections
rather than full sentences. Physical and immediate rather than abstract and eternal.

> Narrator says: *The truth of it was slow to arrive, painful in proportion to how long it
> had been resisted.*
> Character says: *"What happened?"*

A character who speaks with narrative sophistication has broken the gap. Strip the
philosophical vocabulary and replace with the plainest possible statement of their position.

**Vocabulary audit — apply to every line of dialogue:**
1. Take the line of dialogue
2. Locate any word from the philosophical vocabulary lists above
3. If present: rewrite, replacing with the plainest possible equivalent
4. Characters sound like people. Narrators sound like the voice of history with a personal wound.

**Established character registers from source texts:**
- Measured, question-based: *"What happened?" / "Run the numbers."*
- Terse, contemptuous: *"Not good enough." / "Get it done."*
- Epigrammatic: *"This year, then, I hope you will listen."*
- Arch, informative: *"I'll not sweeten this for you."*
- Cold, functional: *"They are mistaken. Such error is fatal."*

Establish a character's register in their first exchange and maintain it. Register shift is
a deliberate signal — use it intentionally or not at all.

---

## Output specification

Return to calling skill:
- Active vocabulary cluster: [which cluster is operating]
- Qualifier scan results: [which of the nine are present, word-distance from nearest repeat,
  any requiring removal]
- Philosophical vocabulary in dialogue: [specific lines flagged and corrected]
- Cluster crossover violations: [words from wrong cluster, corrected]
- Corrected or rewritten passage if needed

---

## Skill relationships

**Called by:**
- `SKILL.md` (master) — vocabulary calibration at end of generation stack
- `mgv-manuscript-diagnosis` — Layer 4 surface vocabulary corrections
- `mgv-thematic-engine` — consults cluster definitions when embedding theme

**Calls:** none — terminal sub-skill

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* active scene mode (determines qualifier eligibility — zero qualifiers
  in action mode), active vocabulary cluster label (derived from `mgv-thematic-engine` output),
  setting brief key terms (from setting onboarding — extends the active cluster for this setting)
- *Returns to master:* cluster confirmed, qualifier scan results (all nine qualifiers — positions
  mapped, any appearing within 400 words of their nearest repeat flagged for removal, any present
  in action mode flagged), philosophical vocabulary in dialogue (specific lines corrected),
  cluster crossover violations (words from wrong cluster identified and replaced), corrected prose
- *Master uses this return to:* confirm vocabulary is calibrated before running style gate (Step 7)

**`mgv-manuscript-diagnosis` → this skill (revision):**
- *Receives from `mgv-manuscript-diagnosis`:* Layer 4 violation list — each item specifies:
  violation type (qualifier clustering / philosophical vocabulary in dialogue / wrong cluster
  words / hope-faith without irony / adverb attribution), exact location (quoted under ten words),
  specific word or phrase requiring correction
- *Processes:* applies `references/violation-taxonomy.md` correction for each violation type
- *Returns to `mgv-manuscript-diagnosis`:* corrected prose passage with all Layer 4 violations
  resolved; confirms no new violations introduced by corrections
- *`mgv-manuscript-diagnosis` uses this return to:* finalise the corrected prose; include in
  output to master

**`mgv-thematic-engine` → this skill (theme verification):**
- *Receives from `mgv-thematic-engine`:* active theme label (which of the four is primary,
  which is secondary if applicable)
- *Processes:* identifies the vocabulary cluster corresponding to the active theme; compiles
  the cluster word list; checks for any cluster crossover in the current passage
- *Returns to `mgv-thematic-engine`:* (a) the vocabulary cluster corresponding to the active
  theme, (b) the specific cluster words for that theme, (c) any words in the current passage
  that conflict with the cluster — flagged as pre-empted crossover violations
- *`mgv-thematic-engine` uses this return to:* verify that the worked examples it generates
  use cluster-appropriate vocabulary and that embedded themes are in the correct register

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
