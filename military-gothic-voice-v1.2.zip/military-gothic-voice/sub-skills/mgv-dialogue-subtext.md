---
name: mgv-dialogue-subtext
version: 1.0.0
title: Military Gothic Voice — Dialogue and Subtext
role: sub-skill
user-invocable: false
model: sonnet
effort: medium
calls: mgv-perspective-interiority
called-by: SKILL.md, mgv-manuscript-diagnosis
---

# Military Gothic Voice — Dialogue and Subtext

Dialogue should not transfer information cleanly. Maximum subtext, minimum statement.
The real meaning is always one step behind the stated meaning.

---

## Sequential thinking procedure

1. Identify the subtext gap: what does each character want that they will not say directly?
2. Apply the five subtext rules to the exchange structure
3. Build exchange rhythm: stripped lines alternating with freighted long lines
4. Set attribution to default ("said"); replace with action beats where possible
5. Verify narrator/dialogue voice gap — consult `mgv-perspective-interiority` if needed
6. Check action beats for the annotation trap — remove any self-explaining beat
7. Verify none of the forbidden dialogue behaviours are present
8. **Rule 3 mandatory check (major scenes):** Confirm Rule 3 appears at least once — a
   character uses affirmative phrasing to contain a critique or refusal. If absent: identify
   the moment of highest tension and reconstruct one exchange to apply it.
9. Return: subtext failures, attribution violations, voice gap violations, revised dialogue

---

## The principle

Maximum subtext. Minimum statement. Characters do not say what they mean. When they approach
meaning they deflect, qualify, or give the correct answer to the wrong question.

**Source text example of maximum subtext:**
> *"What happened to the others?" / "It was cold." / "I know it was cold." / "Yes."*

The listener understands the others are dead. The speaker has confirmed it. Neither stated it.
This is the target state for every significant exchange.

---

## The five subtext rules

### Rule 1: Characters answer questions with different questions or deflections
They do not give the information being asked for. They redirect, qualify, or begin answering
and then pivot.

**Wrong:**
> "Did you know she was coming back?"
> "I had no idea she was planning to return."

**Right:**
> "Did you know she was coming back?"
> "The harbour was open." He set the mug down.

### Rule 2: The most important information is stated in the fewest words
If something matters, it is short. A one-word response carries more weight than a paragraph.
Repetition of a key phrase is a valid — and powerful — form of revelation.

> *"For the dead, mistress. For the dead."*

Two instances. The repetition is the revelation. Nothing more is said.

### Rule 3: Agreement is used to disagree
A character affirming what another has said contains the critique inside the affirmation.
Aim for at least one instance per major scene.

**Source text example:**
> *"'I need to trust a little more.'"*
> *"'You do, siegemaster. You trust.'"*

Philemon is not saying *trust more*. He is saying *your trust is already the problem.* The
affirmative form contains the critique.

### Rule 4: Pauses and beats carry as much weight as lines
What happens between lines — a hesitation, a character moving, a sound from outside — is where
subtext lives. An action beat between two lines is not decoration. It is a line of dialogue in
a different register.

### Rule 4b: Agreement that corrects its own premise
A character can agree with a statement while simultaneously correcting the reason they are
being assumed to agree — and that correction is the real content.

**Source text example:**
> *"'And I too,' said the Lion. 'Not because your words shame me, but because I sense the
> truth of them.'"*

**Structure:** [Agreement] + [not because [rejected premise]] + [but because [actual reason]]

The rejected premise is always an assumption the other character was making about motive, power,
or moral authority. The Lion refuses to let Dorn think he'd shamed him while still agreeing to
come. Use when a character of significant status agrees but must establish their agreement is
not submission.

### Rule 5: Factual response to the emotional question
Characters in political or tactical scenes answer emotional questions with precise facts —
not deflecting but answering the *literal* rather than the emotional content.

> *"What happened?" / "I do not know." / "The bridge is a wreck, lord."*

The precision IS the deflection. The emotional content goes unanswered.

---

## Exchange rhythm — stripped/freighted

Dialogue alternates between stripped bare lines and freighted long lines. Stripped lines do
the real communicative work. Long lines are usually explanation or justification — always
slightly undermined by what comes immediately after.

**Structure:**
> Freighted: *"I could call the fleet, I could tear apart everything he has built, I could
> spend what remains of my reputation on a single action that answers nothing and changes
> nothing and leaves me standing in a ruin I made myself."*
> Stripped: *"But you won't."*

The stripped response does the real work. Responses must be shorter than the speech that
prompted them — always.

---

## Attribution rules

**Default:** *said.* Invisible. Use for most lines.

**Advanced — attribution-free dialogue:**
Two or more consecutive lines with no attribution verb at all. Context and action beats carry
speaker identity. Use when the exchange moves fast and the context makes speaker clear.
> *'Six.' / 'Rather proud of the crews, lord.'*

**Permitted with restraint:** *muttered, asked, replied* — only when volume, register, or
physical modality is narratively relevant. Never for tone.

**Completely forbidden:** Adverb-modified attribution. *Said darkly. Replied coldly. Growled.*
Convey tone through the action beat before or after the line, not in the attribution verb.

**Ellipsis in dialogue — permitted for specific cases:**
Trailing ellipsis marks genuine trailing off — physical weakness, interrupted thought, submission.
> *"Let me be…" she protested, slumping in defeat*
Physiologically real trailing off only. Not for dramatic effect. Never in narration.

**Multi-sentence speech placement:**
Attribution goes after the first sentence, not the last. The character is identified, then
continues uninterrupted.

> Right: *"Come with me," she said. "There isn't time to explain it here."*
> Wrong: *"Come with me. There isn't time to explain it here," she said.*

**Narrator mid-speech commentary** — permitted via em dash:
> *'It can be restored,' he said — not a decision, so much as an acknowledgement of what had
> already been decided.*

---

## Action beats — the annotation trap

Action beats replace attribution. They carry meaning without explanation. The trap: explaining
what the action means.

**Wrong:**
> He set the pin down on the map, the way men do when they need to end an argument without
> admitting they've lost.

**Right:**
> He set the pin down in a different place.

The wrong version explains the meaning. The right version trusts the action to carry it.
If the action cannot carry its meaning without annotation, it is the wrong action — replace
it, or separate the interpretive observation into its own sentence of narration.

**The test:** Remove everything after the action verb. If the meaning collapses, the action
is wrong. If it holds or sharpens, the annotation was deadweight.

---

## The narrator/dialogue voice gap

Characters speak differently from the narrator. This gap is non-negotiable.

See `mgv-vocabulary-fingerprints` for the vocabulary-level application. At the structural level:

> Narrator says: *The truth of it was slow to arrive, painful in proportion to how long it
> had been resisted.*
> Character says: *"What happened?"*

Never give a character a speech that sounds like the narrator. If a character is speaking with
narrative sophistication, something has gone wrong.

---

## What dialogue must never do

- Explain the character's feelings directly
- State the theme of the scene
- Deliver backstory as monologue
- Use the narrator's philosophical vocabulary
- Allow both speakers to agree genuinely — agreement always contains friction
- Answer the question that was actually asked, directly and completely

---

## Output specification

Return to calling skill:
- Subtext failures: [instances where characters said what they meant directly]
- Rules applied or violated: [which of the five]
- Attribution violations: [adverb attributions, wrong placement, annotation traps]
- Voice gap violations: [character speech sounding like narration]
- Rule 3 status: [confirmed present in major scene / added / not applicable (minor exchange)]
- Revised or generated dialogue

---

## Skill relationships

**Called by:**
- `SKILL.md` (master) — when dialogue is primary in the scene
- `mgv-manuscript-diagnosis` — Layer 2 narrator/dialogue voice collapse corrections

**Calls:**
- `mgv-perspective-interiority` — to verify narrator/dialogue voice gap via distance calibration

**Bidirectional data flows:**

**Master → this skill (generation):**
- *Receives from master:* scene type, whether dialogue is primary or supporting, subtext
  requirement level (major scene — Rule 3 mandatory; minor exchange — Rule 3 exempt)
- *Returns to master:* subtext failures list (specific instances where characters stated what
  they meant directly); which of the five rules were applied; attribution violations found and
  corrected (adverb attributions, wrong placement, annotation traps); voice gap violations
  (character speech that sounded like narration, corrected); Rule 3 status (confirmed present /
  added to exchange / not applicable for minor exchange); revised or generated dialogue
- *Master uses this return to:* verify dialogue quality before theme audit at Step 6

**`mgv-manuscript-diagnosis` → this skill (revision):**
- *Receives from `mgv-manuscript-diagnosis`:* Layer 2 voice collapse violations — specifically:
  dialogue lines containing philosophical vocabulary (void, mortal, flesh, soul, shadow, ruin,
  ash, persist, endure, remain), location of each, the specific words requiring replacement
- *Processes:* strips philosophical vocabulary from each flagged dialogue line; rewrites in the
  character's established register (plain, direct, declarative); confirms Rule 3 present in the
  exchange if it is a major scene; notes any subtext failures discovered during correction
  (flagged but not independently corrected — those are dialogue-level violations, not voice-
  collapse violations, and require separate instruction from master)
- *Returns to `mgv-manuscript-diagnosis`:* corrected dialogue exchange with philosophical
  vocabulary removed; character register confirmed; list of any additional dialogue violations
  noticed (flagged only)
- *`mgv-manuscript-diagnosis` uses this return to:* replace the Layer 2 violation with the
  corrected exchange; note any flagged dialogue violations for potential separate instruction

**This skill → `mgv-perspective-interiority` (gap verification):**
- *Sends to `mgv-perspective-interiority`:* the active narrative distance for the current scene
  and a request to confirm the narrator/dialogue gap rules at that distance — specifically whether
  any character dialogue that approaches narrative register requires correction, and what the
  vocabulary characteristics are at close versus mid third
- *Receives from `mgv-perspective-interiority`:* (a) active distance mode confirmed, (b) gap
  rule applies at both distances, (c) close-third vocabulary register for characters (compressed,
  character's own filters, no philosophical vocabulary), (d) mid-third vocabulary register for
  characters (slightly cleaner but still character-inflected, not neutral)
- *Uses this return to:* calibrate gap correctly — ensures dialogue is stripped of vocabulary
  appropriate to the narrative distance, not just simplified generically

---

## Feedback log

Format: `YYYY-MM-DD — observation — action taken / pending`

**Positive feedback:** *(Log here)*
**Negative feedback:** *(Log here)*
